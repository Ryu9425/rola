﻿namespace test1
{
    partial class Detail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.displayBox = new System.Windows.Forms.TextBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.uuidBox = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.standardBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.searchButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.fromYComboBox = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.fromMComboBox = new System.Windows.Forms.ComboBox();
            this.fromDComboBox = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.toDComboBox = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.toMComboBox = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.toYComboBox = new System.Windows.Forms.ComboBox();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lastBtn = new System.Windows.Forms.Button();
            this.nextBtn = new System.Windows.Forms.Button();
            this.btn_5 = new System.Windows.Forms.Button();
            this.btn_4 = new System.Windows.Forms.Button();
            this.btn_3 = new System.Windows.Forms.Button();
            this.btn_2 = new System.Windows.Forms.Button();
            this.btn_1 = new System.Windows.Forms.Button();
            this.preBtn = new System.Windows.Forms.Button();
            this.firstBtn = new System.Windows.Forms.Button();
            this.closeBtn = new System.Windows.Forms.Button();
            this.flowLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // displayBox
            // 
            this.displayBox.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.displayBox.Location = new System.Drawing.Point(128, 0);
            this.displayBox.Margin = new System.Windows.Forms.Padding(0);
            this.displayBox.Name = "displayBox";
            this.displayBox.Size = new System.Drawing.Size(119, 36);
            this.displayBox.TabIndex = 0;
            this.displayBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.displayBox.TextChanged += new System.EventHandler(this.displayBox_TextChanged);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.label11);
            this.flowLayoutPanel1.Controls.Add(this.displayBox);
            this.flowLayoutPanel1.Controls.Add(this.label12);
            this.flowLayoutPanel1.Controls.Add(this.uuidBox);
            this.flowLayoutPanel1.Controls.Add(this.label13);
            this.flowLayoutPanel1.Controls.Add(this.standardBox);
            this.flowLayoutPanel1.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(146, 38);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(727, 38);
            this.flowLayoutPanel1.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label11.Dock = System.Windows.Forms.DockStyle.Left;
            this.label11.Location = new System.Drawing.Point(0, 0);
            this.label11.Margin = new System.Windows.Forms.Padding(0);
            this.label11.MinimumSize = new System.Drawing.Size(120, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(128, 36);
            this.label11.TabIndex = 22;
            this.label11.Text = "設置ポイント";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label12.Location = new System.Drawing.Point(247, 0);
            this.label12.Margin = new System.Windows.Forms.Padding(0);
            this.label12.MinimumSize = new System.Drawing.Size(120, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(120, 36);
            this.label12.TabIndex = 23;
            this.label12.Text = "ID";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uuidBox
            // 
            this.uuidBox.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.uuidBox.Location = new System.Drawing.Point(367, 0);
            this.uuidBox.Margin = new System.Windows.Forms.Padding(0);
            this.uuidBox.Name = "uuidBox";
            this.uuidBox.Size = new System.Drawing.Size(119, 36);
            this.uuidBox.TabIndex = 3;
            this.uuidBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.uuidBox.TextChanged += new System.EventHandler(this.uuidBox_TextChanged);
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label13.Location = new System.Drawing.Point(486, 0);
            this.label13.Margin = new System.Windows.Forms.Padding(0);
            this.label13.MinimumSize = new System.Drawing.Size(120, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(120, 36);
            this.label13.TabIndex = 24;
            this.label13.Text = "基準角度";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // standardBox
            // 
            this.standardBox.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.standardBox.Location = new System.Drawing.Point(606, 0);
            this.standardBox.Margin = new System.Windows.Forms.Padding(0);
            this.standardBox.Name = "standardBox";
            this.standardBox.Size = new System.Drawing.Size(119, 36);
            this.standardBox.TabIndex = 5;
            this.standardBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.standardBox.TextChanged += new System.EventHandler(this.standardBox_TextChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(96, 118);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(105, 26);
            this.button1.TabIndex = 2;
            this.button1.Text = "CSVダウンロード";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // searchButton
            // 
            this.searchButton.BackColor = System.Drawing.Color.DodgerBlue;
            this.searchButton.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.searchButton.Location = new System.Drawing.Point(811, 114);
            this.searchButton.Margin = new System.Windows.Forms.Padding(0);
            this.searchButton.Name = "searchButton";
            this.searchButton.Size = new System.Drawing.Size(62, 41);
            this.searchButton.TabIndex = 3;
            this.searchButton.Text = "検索";
            this.searchButton.UseVisualStyleBackColor = false;
            this.searchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(224, 122);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 21);
            this.label1.TabIndex = 4;
            this.label1.Text = "登録日";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.DodgerBlue;
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(469, 115);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.MinimumSize = new System.Drawing.Size(46, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 15);
            this.label2.TabIndex = 5;
            this.label2.Text = "30日前";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.DodgerBlue;
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(469, 137);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.MinimumSize = new System.Drawing.Size(46, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 15);
            this.label3.TabIndex = 6;
            this.label3.Text = "本日";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.DodgerBlue;
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(741, 137);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.MinimumSize = new System.Drawing.Size(46, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 15);
            this.label4.TabIndex = 8;
            this.label4.Text = "30日後";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.DodgerBlue;
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(741, 115);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.MinimumSize = new System.Drawing.Size(46, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 15);
            this.label5.TabIndex = 7;
            this.label5.Text = "本日";
            // 
            // fromYComboBox
            // 
            this.fromYComboBox.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.fromYComboBox.FormattingEnabled = true;
            this.fromYComboBox.Location = new System.Drawing.Point(287, 118);
            this.fromYComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.fromYComboBox.Name = "fromYComboBox";
            this.fromYComboBox.Size = new System.Drawing.Size(63, 28);
            this.fromYComboBox.TabIndex = 9;
            this.fromYComboBox.SelectedIndexChanged += new System.EventHandler(this.FromYComboBox_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(353, 118);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(16, 21);
            this.label6.TabIndex = 10;
            this.label6.Text = "/";
            // 
            // fromMComboBox
            // 
            this.fromMComboBox.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.fromMComboBox.FormattingEnabled = true;
            this.fromMComboBox.Location = new System.Drawing.Point(366, 119);
            this.fromMComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.fromMComboBox.Name = "fromMComboBox";
            this.fromMComboBox.Size = new System.Drawing.Size(40, 28);
            this.fromMComboBox.TabIndex = 11;
            this.fromMComboBox.SelectedIndexChanged += new System.EventHandler(this.FromMComboBox_SelectedIndexChanged);
            // 
            // fromDComboBox
            // 
            this.fromDComboBox.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.fromDComboBox.FormattingEnabled = true;
            this.fromDComboBox.Location = new System.Drawing.Point(425, 120);
            this.fromDComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.fromDComboBox.Name = "fromDComboBox";
            this.fromDComboBox.Size = new System.Drawing.Size(40, 28);
            this.fromDComboBox.TabIndex = 13;
            this.fromDComboBox.SelectedIndexChanged += new System.EventHandler(this.FromDComboBox_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(410, 119);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(16, 21);
            this.label7.TabIndex = 12;
            this.label7.Text = "/";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(526, 119);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(21, 21);
            this.label8.TabIndex = 14;
            this.label8.Text = "~";
            // 
            // toDComboBox
            // 
            this.toDComboBox.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.toDComboBox.FormattingEnabled = true;
            this.toDComboBox.Location = new System.Drawing.Point(694, 119);
            this.toDComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.toDComboBox.Name = "toDComboBox";
            this.toDComboBox.Size = new System.Drawing.Size(40, 28);
            this.toDComboBox.TabIndex = 19;
            this.toDComboBox.SelectedIndexChanged += new System.EventHandler(this.ToDComboBox_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(680, 120);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(16, 21);
            this.label9.TabIndex = 18;
            this.label9.Text = "/";
            // 
            // toMComboBox
            // 
            this.toMComboBox.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.toMComboBox.FormattingEnabled = true;
            this.toMComboBox.Location = new System.Drawing.Point(637, 118);
            this.toMComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.toMComboBox.Name = "toMComboBox";
            this.toMComboBox.Size = new System.Drawing.Size(40, 28);
            this.toMComboBox.TabIndex = 17;
            this.toMComboBox.SelectedIndexChanged += new System.EventHandler(this.ToMComboBox_SelectedIndexChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(624, 121);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(16, 21);
            this.label10.TabIndex = 16;
            this.label10.Text = "/";
            // 
            // toYComboBox
            // 
            this.toYComboBox.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.toYComboBox.FormattingEnabled = true;
            this.toYComboBox.Location = new System.Drawing.Point(558, 118);
            this.toYComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.toYComboBox.Name = "toYComboBox";
            this.toYComboBox.Size = new System.Drawing.Size(63, 28);
            this.toYComboBox.TabIndex = 15;
            this.toYComboBox.SelectedIndexChanged += new System.EventHandler(this.ToYComboBox_SelectedIndexChanged);
            // 
            // dataGridView
            // 
            this.dataGridView.AllowUserToAddRows = false;
            this.dataGridView.AllowUserToDeleteRows = false;
            this.dataGridView.AllowUserToResizeColumns = false;
            this.dataGridView.AllowUserToResizeRows = false;
            this.dataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dataGridView.BackgroundColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowFrame;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridView.Location = new System.Drawing.Point(40, 176);
            this.dataGridView.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.ReadOnly = true;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.ControlDark;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView.RowTemplate.Height = 25;
            this.dataGridView.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataGridView.Size = new System.Drawing.Size(904, 441);
            this.dataGridView.TabIndex = 20;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lastBtn);
            this.groupBox1.Controls.Add(this.nextBtn);
            this.groupBox1.Controls.Add(this.btn_5);
            this.groupBox1.Controls.Add(this.btn_4);
            this.groupBox1.Controls.Add(this.btn_3);
            this.groupBox1.Controls.Add(this.btn_2);
            this.groupBox1.Controls.Add(this.btn_1);
            this.groupBox1.Controls.Add(this.preBtn);
            this.groupBox1.Controls.Add(this.firstBtn);
            this.groupBox1.Location = new System.Drawing.Point(238, 616);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(562, 58);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            // 
            // lastBtn
            // 
            this.lastBtn.AutoSize = true;
            this.lastBtn.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.lastBtn.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lastBtn.ForeColor = System.Drawing.Color.MediumBlue;
            this.lastBtn.Location = new System.Drawing.Point(477, 17);
            this.lastBtn.Margin = new System.Windows.Forms.Padding(8);
            this.lastBtn.MaximumSize = new System.Drawing.Size(80, 30);
            this.lastBtn.MinimumSize = new System.Drawing.Size(80, 30);
            this.lastBtn.Name = "lastBtn";
            this.lastBtn.Size = new System.Drawing.Size(80, 30);
            this.lastBtn.TabIndex = 8;
            this.lastBtn.Text = "last";
            this.lastBtn.UseVisualStyleBackColor = true;
            this.lastBtn.Click += new System.EventHandler(this.lastBtn_Click);
            // 
            // nextBtn
            // 
            this.nextBtn.AutoSize = true;
            this.nextBtn.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.nextBtn.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.nextBtn.ForeColor = System.Drawing.Color.MediumBlue;
            this.nextBtn.Location = new System.Drawing.Point(395, 17);
            this.nextBtn.Margin = new System.Windows.Forms.Padding(8);
            this.nextBtn.MaximumSize = new System.Drawing.Size(80, 30);
            this.nextBtn.MinimumSize = new System.Drawing.Size(80, 30);
            this.nextBtn.Name = "nextBtn";
            this.nextBtn.Size = new System.Drawing.Size(80, 30);
            this.nextBtn.TabIndex = 7;
            this.nextBtn.Text = "next";
            this.nextBtn.UseVisualStyleBackColor = true;
            this.nextBtn.Click += new System.EventHandler(this.nextBtn_Click);
            // 
            // btn_5
            // 
            this.btn_5.AutoSize = true;
            this.btn_5.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_5.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_5.ForeColor = System.Drawing.Color.MediumBlue;
            this.btn_5.Location = new System.Drawing.Point(352, 17);
            this.btn_5.Margin = new System.Windows.Forms.Padding(20);
            this.btn_5.MaximumSize = new System.Drawing.Size(40, 30);
            this.btn_5.MinimumSize = new System.Drawing.Size(40, 30);
            this.btn_5.Name = "btn_5";
            this.btn_5.Size = new System.Drawing.Size(40, 30);
            this.btn_5.TabIndex = 6;
            this.btn_5.Text = "5";
            this.btn_5.UseVisualStyleBackColor = true;
            this.btn_5.Click += new System.EventHandler(this.btn_5_Click);
            // 
            // btn_4
            // 
            this.btn_4.AutoSize = true;
            this.btn_4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_4.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_4.ForeColor = System.Drawing.Color.MediumBlue;
            this.btn_4.Location = new System.Drawing.Point(306, 17);
            this.btn_4.Margin = new System.Windows.Forms.Padding(8);
            this.btn_4.MaximumSize = new System.Drawing.Size(40, 30);
            this.btn_4.MinimumSize = new System.Drawing.Size(40, 30);
            this.btn_4.Name = "btn_4";
            this.btn_4.Size = new System.Drawing.Size(40, 30);
            this.btn_4.TabIndex = 5;
            this.btn_4.Text = "4";
            this.btn_4.UseVisualStyleBackColor = true;
            this.btn_4.Click += new System.EventHandler(this.btn_4_Click);
            // 
            // btn_3
            // 
            this.btn_3.AutoSize = true;
            this.btn_3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_3.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_3.ForeColor = System.Drawing.Color.MediumBlue;
            this.btn_3.Location = new System.Drawing.Point(261, 17);
            this.btn_3.Margin = new System.Windows.Forms.Padding(8);
            this.btn_3.MaximumSize = new System.Drawing.Size(40, 30);
            this.btn_3.MinimumSize = new System.Drawing.Size(40, 30);
            this.btn_3.Name = "btn_3";
            this.btn_3.Size = new System.Drawing.Size(40, 30);
            this.btn_3.TabIndex = 4;
            this.btn_3.Text = "3";
            this.btn_3.UseVisualStyleBackColor = true;
            this.btn_3.Click += new System.EventHandler(this.btn_3_Click);
            // 
            // btn_2
            // 
            this.btn_2.AutoSize = true;
            this.btn_2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_2.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_2.ForeColor = System.Drawing.Color.MediumBlue;
            this.btn_2.Location = new System.Drawing.Point(216, 17);
            this.btn_2.Margin = new System.Windows.Forms.Padding(8);
            this.btn_2.MaximumSize = new System.Drawing.Size(40, 30);
            this.btn_2.MinimumSize = new System.Drawing.Size(40, 30);
            this.btn_2.Name = "btn_2";
            this.btn_2.Size = new System.Drawing.Size(40, 30);
            this.btn_2.TabIndex = 3;
            this.btn_2.Text = "2";
            this.btn_2.UseVisualStyleBackColor = true;
            this.btn_2.Click += new System.EventHandler(this.btn_2_Click);
            // 
            // btn_1
            // 
            this.btn_1.AutoSize = true;
            this.btn_1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_1.ForeColor = System.Drawing.Color.MediumBlue;
            this.btn_1.Location = new System.Drawing.Point(171, 17);
            this.btn_1.Margin = new System.Windows.Forms.Padding(8);
            this.btn_1.MaximumSize = new System.Drawing.Size(40, 30);
            this.btn_1.MinimumSize = new System.Drawing.Size(40, 30);
            this.btn_1.Name = "btn_1";
            this.btn_1.Size = new System.Drawing.Size(40, 30);
            this.btn_1.TabIndex = 2;
            this.btn_1.Text = "1";
            this.btn_1.UseVisualStyleBackColor = true;
            this.btn_1.Click += new System.EventHandler(this.btn_1_Click);
            // 
            // preBtn
            // 
            this.preBtn.AutoSize = true;
            this.preBtn.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.preBtn.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.preBtn.ForeColor = System.Drawing.Color.MediumBlue;
            this.preBtn.Location = new System.Drawing.Point(87, 17);
            this.preBtn.Margin = new System.Windows.Forms.Padding(12);
            this.preBtn.MaximumSize = new System.Drawing.Size(80, 30);
            this.preBtn.MinimumSize = new System.Drawing.Size(80, 30);
            this.preBtn.Name = "preBtn";
            this.preBtn.Size = new System.Drawing.Size(80, 30);
            this.preBtn.TabIndex = 1;
            this.preBtn.Text = "pre";
            this.preBtn.UseVisualStyleBackColor = true;
            this.preBtn.Click += new System.EventHandler(this.preBtn_Click);
            // 
            // firstBtn
            // 
            this.firstBtn.AutoSize = true;
            this.firstBtn.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.firstBtn.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.firstBtn.ForeColor = System.Drawing.Color.MediumBlue;
            this.firstBtn.Location = new System.Drawing.Point(4, 17);
            this.firstBtn.Margin = new System.Windows.Forms.Padding(8);
            this.firstBtn.MaximumSize = new System.Drawing.Size(80, 30);
            this.firstBtn.MinimumSize = new System.Drawing.Size(80, 30);
            this.firstBtn.Name = "firstBtn";
            this.firstBtn.Size = new System.Drawing.Size(80, 30);
            this.firstBtn.TabIndex = 0;
            this.firstBtn.Text = "first";
            this.firstBtn.UseVisualStyleBackColor = true;
            this.firstBtn.Click += new System.EventHandler(this.firstBtn_Click);
            // 
            // closeBtn
            // 
            this.closeBtn.Location = new System.Drawing.Point(914, 2);
            this.closeBtn.Name = "closeBtn";
            this.closeBtn.Size = new System.Drawing.Size(54, 41);
            this.closeBtn.TabIndex = 22;
            this.closeBtn.Text = "CLOSE";
            this.closeBtn.UseVisualStyleBackColor = true;
            this.closeBtn.Click += new System.EventHandler(this.button2_Click);
            // 
            // Detail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(980, 672);
            this.Controls.Add(this.closeBtn);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridView);
            this.Controls.Add(this.toDComboBox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.toMComboBox);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.toYComboBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.fromDComboBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.fromMComboBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.fromYComboBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.searchButton);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.flowLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximumSize = new System.Drawing.Size(1000, 800);
            this.MinimumSize = new System.Drawing.Size(900, 550);
            this.Name = "Detail";
            this.Text = "Web Data";
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox displayBox;
        private FlowLayoutPanel flowLayoutPanel1;
        private TextBox uuidBox;
        private TextBox standardBox;
        private Button button1;
        private Button searchButton;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private ComboBox fromYComboBox;
        private Label label6;
        private ComboBox fromMComboBox;
        private ComboBox fromDComboBox;
        private Label label7;
        private Label label8;
        private ComboBox toDComboBox;
        private Label label9;
        private ComboBox toMComboBox;
        private Label label10;
        private ComboBox toYComboBox;
        private DataGridView dataGridView;
        private GroupBox groupBox1;
        private Button firstBtn;
        private Button lastBtn;
        private Button nextBtn;
        private Button btn_5;
        private Button btn_4;
        private Button btn_3;
        private Button btn_2;
        private Button btn_1;
        private Button preBtn;
        private Label label11;
        private Label label12;
        private Label label13;
        private Button closeBtn;
    }
}